# flow saver plugin

This plugin can count the flows from every port. It can not use alone, must be use with other plugins.
