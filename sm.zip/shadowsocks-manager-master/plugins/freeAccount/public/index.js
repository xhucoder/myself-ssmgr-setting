exports.app = angular.module('app', ['ngMaterial', 'ui.router', 'ngMessages', 'ja.qr']);
